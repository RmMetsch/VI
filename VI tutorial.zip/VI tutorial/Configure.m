function Configure(obj)

    Model = string(query(obj.Instr, "*IDN?"));
   
    % Model DMM6500 
    if contains(Model, "DMM6500" )
        obj.SCPI = ":READ?";
    end

    % model 2700
    if contains(Model, "MODEL 2700")
        obj.SCPI = "READ?";
        write(obj.Instr, "FORM:ELEM READ")
    end

    % Model 2182 A nanovoltmeter
    if contains(Model, "MODEL 2182A")
        obj.SCPI = "SENS:CHAN "+ obj.Channel + "; DATA?";
    end

    if contains(Model, "MODEL 2700")
        obj.SCPI = 'SENS:DATA?';
    end

    if contains(Model,"2200-20-5")
        obj.SCPI = "SOUR:VOLT";
    end

    % LakeShore temperature controler MODEL336
    if contains(Model,"MODEL336")
        obj.SCPI = "KRDG? "+ obj.Channel; 
    end
    
    if contains(Model, "33521B")
        write(obj.Instr,"FUNC DC")
        obj.SCPI = "VOLT:OFFSET";
    end




end


